package com.test.jiogarden.feeds;

import twitter4j.Paging;
import twitter4j.ResponseList;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.UserMentionEntity;
import twitter4j.api.TimelinesResources;
import twitter4j.api.UsersResources;
import twitter4j.conf.ConfigurationBuilder;

public class TwitterFeeds {

	public static void main(String[] args) throws TwitterException {

		ConfigurationBuilder conf = new ConfigurationBuilder();
		conf.setOAuthConsumerKey("pba6VIoFgzhySunJIWsj0fJAD");
		conf.setOAuthConsumerSecret("523sBx13t8kO7knOjGZPbwr6u2yc5Coj6brCNEfu8ozYmLUJxi");
		conf.setOAuthAccessToken("852461664058441728-RJ6fAckF0639dJMQMMz41I6QpB2VkbI");
		conf.setOAuthAccessTokenSecret("r74tHmM0KDQPvVQo8ctbTr52XMxRpjalJDhwyPvVlbOgf");

		TwitterFactory twitterFactory = new TwitterFactory(conf.build());
		TimelinesResources timelinesResources = twitterFactory.getInstance();

		ResponseList<Status> status = timelinesResources
				.getHomeTimeline(new Paging(1, 2));

		for (Status stuss : status) {

			UserMentionEntity[] userMentionEntities = stuss
					.getUserMentionEntities();

			for (UserMentionEntity users : userMentionEntities) {
				UsersResources usersResources = twitterFactory.getInstance();
				User user = usersResources.showUser(users.getId());
				System.out.println(user.getProfileImageURL());
				System.out.println(user.getScreenName());
				System.out.println(user.getName());
				System.out.println(user.getFavouritesCount());
				System.out.println(user.getStatusesCount());
			}
		}

	}
}
